// Interactive behavior for ClickGrown's accessible navigation, metrics, and testimonial carousel.
document.addEventListener('DOMContentLoaded', () => {
  lucide.createIcons();
  const toggle = document.getElementById('menu-toggle');
  const menu = document.getElementById('mobile-menu');
  toggle.addEventListener('click', () => { const open = menu.classList.toggle('hidden') === false; toggle.setAttribute('aria-expanded', open); });
  menu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => { menu.classList.add('hidden'); toggle.setAttribute('aria-expanded', 'false'); }));
  const counters = document.querySelectorAll('.counter'); let counted = false;
  const runCounters = () => { if (counted) return; counted = true; counters.forEach(counter => { const target = Number(counter.dataset.target); const prefix = counter.dataset.prefix || ''; const suffix = counter.dataset.suffix || ''; const start = performance.now(); const animate = now => { const progress = Math.min((now - start) / 1300, 1); const value = Math.floor((1 - Math.pow(1 - progress, 3)) * target); counter.textContent = `${prefix}${value}${suffix}`; if (progress < 1) requestAnimationFrame(animate); }; requestAnimationFrame(animate); }); };
  new IntersectionObserver(entries => entries.forEach(entry => { if (entry.isIntersecting) runCounters(); }), { threshold: .35 }).observe(document.getElementById('results'));
  const reviews = [...document.querySelectorAll('.testimonial')]; let active = 1; const updateReviews = () => reviews.forEach((review, index) => review.classList.toggle('featured', index === active)); document.getElementById('prev-review').addEventListener('click', () => { active = (active + reviews.length - 1) % reviews.length; updateReviews(); }); document.getElementById('next-review').addEventListener('click', () => { active = (active + 1) % reviews.length; updateReviews(); });
  document.getElementById('newsletter-form').addEventListener('submit', event => { event.preventDefault(); event.currentTarget.reset(); document.getElementById('form-message').classList.remove('hidden'); });
});
