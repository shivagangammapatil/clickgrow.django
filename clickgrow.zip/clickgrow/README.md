# ClickGrown

Modern, responsive growth-agency landing page.

## Structure

- `Frontend/` — semantic HTML, Tailwind-powered styling, and interactive JavaScript
- `Backend/` — minimal Node.js API scaffold
- `banckend/` — Django authentication backend with SQLite, registration, login, logout, and dashboard

Open `Frontend/index.html` in a browser to preview the site. To start the optional API health endpoint, run `node Backend/server.js` and visit `/api/health`.

See `banckend/README.md` for Django setup and launch instructions.
