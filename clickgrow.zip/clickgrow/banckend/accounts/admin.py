from django.contrib import admin

# Django's built-in User admin is available at /admin/ after creating a superuser.
