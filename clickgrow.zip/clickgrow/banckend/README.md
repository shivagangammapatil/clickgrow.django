# ClickGrown Django Backend

This folder contains the Django authentication backend. It uses SQLite (`db.sqlite3`) by default and includes login, registration, logout, a protected dashboard, and Django admin.

## Run locally

1. Install Python 3.10+.
2. In this folder, run `python -m venv .venv` and activate it.
3. Run `pip install -r requirements.txt`.
4. Run `python manage.py migrate`.
5. Run `python manage.py runserver`.
6. Open `http://127.0.0.1:8000/register/` to create an account.

For the admin panel, run `python manage.py createsuperuser` and visit `/admin/`.

Before deploying, replace `SECRET_KEY`, set `DEBUG = False`, and configure `ALLOWED_HOSTS` in `clickgrown_backend/settings.py`.
