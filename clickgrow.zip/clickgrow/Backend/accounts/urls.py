from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register/', views.register, name='register'),
    path('login/', views.sign_in, name='login'),
    path('logout/', views.sign_out, name='logout'),
    path('api/auth/register/', views.api_register, name='api-register'),
    path('api/auth/login/', views.api_login, name='api-login'),
    path('api/auth/logout/', views.api_logout, name='api-logout'),
    path('api/auth/session/', views.api_session, name='api-session'),
]
