import json
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.views.decorators.csrf import ensure_csrf_cookie
from django.views.decorators.http import require_http_methods, require_POST
from .forms import SignInForm, SignUpForm


@ensure_csrf_cookie
def home(request):
    """Serves the original ClickGrown landing-page template."""
    return render(request, 'index.html')


def register(request):
    if request.user.is_authenticated:
        return redirect('home')
    form = SignUpForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Account created successfully. Please log in to continue.')
        return redirect('login')
    return render(request, 'accounts/register.html', {'form': form})


def sign_in(request):
    if request.user.is_authenticated:
        return redirect('home')
    form = SignInForm(request, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        login(request, form.get_user())
        messages.success(request, 'Welcome back to ClickGrown.')
        return redirect('home')
    return render(request, 'accounts/login.html', {'form': form})


@require_POST
def sign_out(request):
    logout(request)
    messages.success(request, 'You have been logged out.')
    return redirect('home')


def _json_body(request):
    try:
        return json.loads(request.body.decode('utf-8'))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None


@require_POST
def api_register(request):
    payload = _json_body(request)
    if payload is None:
        return JsonResponse({'detail': 'A valid JSON body is required.'}, status=400)
    form = SignUpForm(payload)
    if not form.is_valid():
        return JsonResponse({'errors': form.errors.get_json_data()}, status=400)
    user = form.save()
    login(request, user)
    return JsonResponse({'message': 'Registration successful.', 'user': {'id': user.id, 'username': user.username, 'email': user.email}}, status=201)


@require_POST
def api_login(request):
    payload = _json_body(request)
    if payload is None:
        return JsonResponse({'detail': 'A valid JSON body is required.'}, status=400)
    username, password = payload.get('username', ''), payload.get('password', '')
    user = authenticate(request, username=username, password=password)
    if user is None:
        return JsonResponse({'detail': 'Invalid username or password.'}, status=400)
    login(request, user)
    return JsonResponse({'message': 'Login successful.', 'user': {'id': user.id, 'username': user.username, 'email': user.email}})


@require_POST
def api_logout(request):
    logout(request)
    return JsonResponse({'message': 'Logout successful.'})


@require_http_methods(['GET'])
def api_session(request):
    if not request.user.is_authenticated:
        return JsonResponse({'authenticated': False}, status=401)
    user = request.user
    return JsonResponse({'authenticated': True, 'user': {'id': user.id, 'username': user.username, 'email': user.email, 'first_name': user.first_name}})
