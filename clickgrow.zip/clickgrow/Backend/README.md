# ClickGrown Django Backend

This Django project serves the existing `Frontend/index.html` as its homepage and uses SQLite by default. It includes validated, session-based authentication and JSON auth APIs.

## Start

1. Install Python 3.10+.
2. From this folder: `python -m venv .venv`
3. Activate it, then: `pip install -r requirements.txt`
4. Run: `python manage.py migrate`
5. Run: `python manage.py runserver`

Visit `http://127.0.0.1:8000/`. Registration redirects to login, and successful login redirects to the homepage.

## Auth API

All mutating endpoints are protected by Django CSRF middleware. For browser JSON requests, send the `X-CSRFToken` header using the `csrftoken` cookie obtained from the homepage.

| Method | Endpoint | Purpose |
| --- | --- | --- |
| POST | `/api/auth/register/` | Register and begin a session |
| POST | `/api/auth/login/` | Authenticate and begin a session |
| POST | `/api/auth/logout/` | End the active session |
| GET | `/api/auth/session/` | Read current session user |

Before deployment, set a secure `SECRET_KEY`, use `DEBUG=False`, and configure `ALLOWED_HOSTS`.
